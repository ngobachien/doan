import React from "react";
import PeriCuePage from "./chinn/PeriCuePage";
import CueShop from "./chinn/CueShop";
import "./peri.css";

function Peri() {
  return (
    <div className="test-page">
      <PeriCuePage />
      <CueShop />
    </div>
  );
}

export default Peri;