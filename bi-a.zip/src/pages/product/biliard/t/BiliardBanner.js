import React from "react";
import "./BiliardBanner.css";

const BiliardBanner = () => (
  <div className="biliard-banner">
    <h1>GẬY BI-A</h1>
  </div>
);

export default BiliardBanner; 