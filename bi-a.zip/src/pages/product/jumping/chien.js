import React from "react";
import Chie from "./chie/chie";
import "./chien.css";

function chien() {
  return (
    <div className="test-page">
      <Chie />
    </div>
  );
}

export default chien