import React from "react";
import AllProductsBanner from "./test/AllProductsBanner";
import AllProduct from "./test/AllProduct";
import "./test.css";

function Test() {
  return (
    <div className="test-page">
        <AllProductsBanner />
      <AllProduct />
    </div>
  );
}

export default Test;