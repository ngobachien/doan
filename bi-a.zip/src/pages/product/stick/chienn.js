import React from "react";
import BreakingStick from "./ch/BreakingStick";
import "./chienn.css";

function chienn() {
  return (
    <div className="test-page">
      <BreakingStick />
    </div>
  );
}

export default chienn